Usage:
	"Welcome" function to test if server is running.
		curl -X GET "http://localhost:8080/"
	"addNewStud" function adds a new student to the database.
		curl -d '{"stdId": 130267, "firstName": "Medina", "lastName": "Sulejmani", "faculty": "cst", "cgpa": 8.3}' -H "Content-Type: application/json" -X POST "http://localhost:8080/restapi/std"
	"getStud" function finds a student, it has been overload to find by id or by faculty.
		By id:
		curl -X GET "http://localhost:8080/restapi/std?stdId=130267"
		By faculty:
		curl -X GET "http://localhost:8080/restapi/stdfac?fac=CST"
	"getStuds" function returns all students in the database.
		curl -X GET "http://localhost:8080/restapi/getstdall"
	"deleteStud" function deletes a student from the database by given id.
		curl -X DELETE "http://localhost:8080/restapi/std?stdid=130267"
Dependencies:
	1. groupID = org.springframework.boot	artifactID = spring-boot-starter-data-jpa
	2. groupID = org.springframework.boot	artifactID = spring-boot-starter-web
	3. groupID = com.mysql					artifactID = mysql-connector-j
	4. groupID = org.springframework.boot	artifactID = spring-boot-starter-test
package com.medi.StudentDataRestApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentDataRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
